$( document ).ready(function() {
	// Handler for .ready() called.
	// Detect and set the timezone cookie.
	$.cookie("browser.timezone", jstz.determine().name(), { expires: 365, path: '/' });
});