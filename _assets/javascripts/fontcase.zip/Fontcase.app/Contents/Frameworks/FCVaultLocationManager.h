// Created by Pieter Omvlee on 04/10/2012.
// Copyright Bohemian Coding

@interface FCVaultLocationManager : NSObject
+ (NSURL *)locationOfVault;
+ (BOOL)letUserPickExistingVault;

+ (void)stopUsingCurrentVault;
@end